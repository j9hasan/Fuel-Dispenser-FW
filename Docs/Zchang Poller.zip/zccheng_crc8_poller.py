# ZCheng (Zhejiang Genuine) RS-485 Poller
# Protocol: A5 header, CRC8 checksum, per Genuine Protocol PDF
# Baud: 4800 8N1

import serial, time

COM_PORT = "COM3"  # Change to your COM port
BAUD = 4800
TIMEOUT = 0.1
DEVICE_ADDR = 0x01

CRC8_TAB = [
    0x00,
    0x5E,
    0xBC,
    0xE2,
    0x61,
    0x3F,
    0xDD,
    0x83,
    0xC2,
    0x9C,
    0x7E,
    0x20,
    0xA3,
    0xFD,
    0x1F,
    0x41,
    0x9D,
    0xC3,
    0x21,
    0x7F,
    0xFC,
    0xA2,
    0x40,
    0x1E,
    0x5F,
    0x01,
    0xE3,
    0xBD,
    0x3E,
    0x60,
    0x82,
    0xDC,
    0x23,
    0x7D,
    0x9F,
    0xC1,
    0x42,
    0x1C,
    0xFE,
    0xA0,
    0xE1,
    0xBF,
    0x5D,
    0x03,
    0x80,
    0xDE,
    0x3C,
    0x62,
    0xBE,
    0xE0,
    0x02,
    0x5C,
    0xDF,
    0x81,
    0x63,
    0x3D,
    0x7C,
    0x22,
    0xC0,
    0x9E,
    0x1D,
    0x43,
    0xA1,
    0xFF,
    0x46,
    0x18,
    0xFA,
    0xA4,
    0x27,
    0x79,
    0x9B,
    0xC5,
    0x84,
    0xDA,
    0x38,
    0x66,
    0xE5,
    0xBB,
    0x59,
    0x07,
    0xDB,
    0x85,
    0x67,
    0x39,
    0xBA,
    0xE4,
    0x06,
    0x58,
    0x19,
    0x47,
    0xA5,
    0xFB,
    0x78,
    0x26,
    0xC4,
    0x9A,
    0x65,
    0x3B,
    0xD9,
    0x87,
    0x04,
    0x5A,
    0xB8,
    0xE6,
    0xA7,
    0xF9,
    0x1B,
    0x45,
    0xC6,
    0x98,
    0x7A,
    0x24,
    0xF8,
    0xA6,
    0x44,
    0x1A,
    0x99,
    0xC7,
    0x25,
    0x7B,
    0x3A,
    0x64,
    0x86,
    0xD8,
    0x5B,
    0x05,
    0xE7,
    0xB9,
    0x8C,
    0xD2,
    0x30,
    0x6E,
    0xED,
    0xB3,
    0x51,
    0x0F,
    0x4E,
    0x10,
    0xF2,
    0xAC,
    0x2F,
    0x71,
    0x93,
    0xCD,
    0x11,
    0x4F,
    0xAD,
    0xF3,
    0x70,
    0x2E,
    0xCC,
    0x92,
    0xD3,
    0x8D,
    0x6F,
    0x31,
    0xB2,
    0xEC,
    0x0E,
    0x50,
    0xAF,
    0xF1,
    0x13,
    0x4D,
    0xCE,
    0x90,
    0x72,
    0x2C,
    0x6D,
    0x33,
    0xD1,
    0x8F,
    0x0C,
    0x52,
    0xB0,
    0xEE,
    0x32,
    0x6C,
    0x8E,
    0xD0,
    0x53,
    0x0D,
    0xEF,
    0xB1,
    0xF0,
    0xAE,
    0x4C,
    0x12,
    0x91,
    0xCF,
    0x2D,
    0x73,
    0xCA,
    0x94,
    0x76,
    0x28,
    0xAB,
    0xF5,
    0x17,
    0x49,
    0x08,
    0x56,
    0xB4,
    0xEA,
    0x69,
    0x37,
    0xD5,
    0x8B,
    0x57,
    0x09,
    0xEB,
    0xB5,
    0x36,
    0x68,
    0x8A,
    0xD4,
    0x95,
    0xCB,
    0x29,
    0x77,
    0xF4,
    0xAA,
    0x48,
    0x16,
    0xE9,
    0xB7,
    0x55,
    0x0B,
    0x88,
    0xD6,
    0x34,
    0x6A,
    0x2B,
    0x75,
    0x97,
    0xC9,
    0x4A,
    0x14,
    0xF6,
    0xA8,
    0x74,
    0x2A,
    0xC8,
    0x96,
    0x15,
    0x4B,
    0xA9,
    0xF7,
    0xB6,
    0xE8,
    0x0A,
    0x54,
    0xD7,
    0x89,
    0x6B,
    0x35,
]


def crc8(payload: bytes) -> int:
    c = 0
    for b in payload:
        c = CRC8_TAB[c ^ b]
    return c


def build_read(addr: int, origin: int, length: int) -> bytes:
    body = bytes([addr, 0x03, origin, length])
    return b"\xa5" + body + bytes([crc8(body)])


def parse_slave(frame: bytes):
    if not frame or frame[0] != 0xA5:
        return None
    addr, func, length = frame[1], frame[2], frame[3]
    data = frame[4 : 4 + length]
    if crc8(bytes([addr, func, length]) + data) != frame[-1]:
        return None
    return addr, func, data


def bcd_to_float(b: bytes, decimals=2):
    digits = "".join(f"{x:02X}" for x in b).lstrip("0") or "0"
    if len(digits) <= decimals:
        digits = digits.zfill(decimals + 1)
    return float(f"{int(digits[:-decimals])}.{digits[-decimals:]}")


def read_status(ser):
    pkt = build_read(DEVICE_ADDR, 0x00, 0x01)
    ser.reset_input_buffer()
    ser.write(pkt)
    resp = ser.read(64)
    parsed = parse_slave(resp)
    if not parsed:
        return None
    code = parsed[2][0]
    return {
        0x00: "IDLE",
        0x01: "REQ_START_LITRE",
        0x02: "REQ_START_SALE",
        0x03: "STOP_REQUIRED",
        0x04: "BUSY/DISPENSING",
        0x05: "NOZZLE_NOT_RETURNED",
        0x06: "AFTER_RESTART",
    }.get(code, f"UNK({code:02X})")


def read_realtime(ser):
    pkt = build_read(DEVICE_ADDR, 0x20, 0x08)
    ser.reset_input_buffer()
    ser.write(pkt)
    resp = ser.read(128)
    parsed = parse_slave(resp)
    if not parsed:
        return None
    d = parsed[2]
    return bcd_to_float(d[0:3]), bcd_to_float(d[4:8])


def read_stopped(ser):
    pkt = build_read(DEVICE_ADDR, 0x30, 0x08)
    ser.reset_input_buffer()
    ser.write(pkt)
    resp = ser.read(128)
    parsed = parse_slave(resp)
    if not parsed:
        return None
    d = parsed[2]
    return bcd_to_float(d[0:3]), bcd_to_float(d[4:8])


def read_unit_price(ser):
    pkt = build_read(DEVICE_ADDR, 0x55, 0x04)
    ser.reset_input_buffer()
    ser.write(pkt)
    resp = ser.read(128)
    parsed = parse_slave(resp)
    if not parsed:
        return None
    return bcd_to_float(parsed[2])


def main():
    with serial.Serial(COM_PORT, BAUD, timeout=TIMEOUT) as ser:
        while True:
            status = read_status(ser)
            if status:
                print("[status]", status)
            if status == "BUSY/DISPENSING":
                rt = read_realtime(ser)
                if rt:
                    print(f"[live] Vol={rt[0]:.2f}L Sale={rt[1]:.2f}")
            elif status in ("STOP_REQUIRED", "IDLE"):
                st = read_stopped(ser)
                if st and (st[0] > 0 or st[1] > 0):
                    print(f"[stopped] Vol={st[0]:.2f}L Sale={st[1]:.2f}")
            price = read_unit_price(ser)
            if price:
                print(f"[price] {price:.2f}/L")
            time.sleep(0.1)


if __name__ == "__main__":
    main()
